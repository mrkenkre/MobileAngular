export class Mobile {
  mobId : number;
  mobName : string;
  mobPrice : number;
  
 constructor(mobId:number,mobName:string,mobPrice:number){
     this.mobId=mobId;
     this.mobName=mobName;
     this.mobPrice=mobPrice;
 }
}