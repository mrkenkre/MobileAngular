"use strict";
var Mobile = (function () {
    function Mobile(mobId, mobName, mobPrice) {
        this.mobId = mobId;
        this.mobName = mobName;
        this.mobPrice = mobPrice;
    }
    return Mobile;
}());
exports.Mobile = Mobile;
